using Microsoft.EntityFrameworkCore;

namespace HelloNoteApp;

/// <summary>
/// A classe herda de dbcontext do entity framework core.
/// Esta é a classe principal que coordena a funcionalidade do entity framework,
/// para um dado modelo de dados.
/// </summary>
public class AppDbContext: DbContext
{
    //representa uma coleção para uma dada entidade dentro do modelo
    //é o método primário para interação com o banco
    public DbSet<Nota> Notas { get; set; }
    
    //armazena o caminho no qual o banco é armazenado
    public string DbPath { get; set; }


    /// <summary>
    /// construtor da classe
    /// </summary>
    public AppDbContext()
    {
        //para ser cross-platform precisamos que o .net encontre o 
        //diretório de aplicação baseado no ambiente
        var folder = Environment.SpecialFolder.LocalApplicationData;
        
        var path = Environment.GetFolderPath(folder);

        DbPath = Path.Join(path, "notas.db");
    }
    
    /// <summary>
    /// metodo sobrescrito de configuração para o banco sqlite com o caminho do banco
    /// serve para configurar o acesso ao banco de dados quando o contexto é criado
    /// Esse método é chamado automaticamente pelo Entity Framework Core quando o
    /// DbContext está sendo configurado.
    /// $"Data Source={DbPath}" - Isso monta a string de conexão, definindo qual arquivo .db será usado.
    /// </summary>
    /// <param name="optionsBuilder"></param>
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) => 
        optionsBuilder.UseSqlite($"Data Source={DbPath}");
}